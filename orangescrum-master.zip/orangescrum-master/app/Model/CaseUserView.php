<?php
class CaseUserView extends AppModel{
	var $name = 'CaseUserView';
}