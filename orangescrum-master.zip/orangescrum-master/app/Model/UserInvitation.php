<?php
class UserInvitation extends AppModel{
	var $name = 'UserInvitation';
}