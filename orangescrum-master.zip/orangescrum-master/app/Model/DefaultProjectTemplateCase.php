<?php
class DefaultProjectTemplateCase extends AppModel{
	var $name = 'DefaultProjectTemplateCase';
}