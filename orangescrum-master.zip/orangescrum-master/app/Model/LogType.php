<?php
class LogType extends AppModel{
	var $name = 'LogType';
}