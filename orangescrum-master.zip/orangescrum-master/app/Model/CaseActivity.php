<?php
class CaseActivity extends AppModel{
	var $name = 'CaseActivity';
}