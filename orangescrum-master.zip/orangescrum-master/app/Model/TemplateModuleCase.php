<?php
class TemplateModuleCase extends AppModel{
	var $name = 'TemplateModuleCase';
}