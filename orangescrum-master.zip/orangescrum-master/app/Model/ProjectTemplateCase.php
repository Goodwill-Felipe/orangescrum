<?php
class ProjectTemplateCase extends AppModel{
	var $name = 'ProjectTemplateCase';
}